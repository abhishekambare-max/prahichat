// Node.js + Express server setup
console.log('Prahichat backend');